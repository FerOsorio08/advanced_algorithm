        return fScore[a] < fScore[b];
        });